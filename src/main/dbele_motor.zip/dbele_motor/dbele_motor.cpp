#include "dbele_motor.h"

DB_Motor::DB_Motor(int enA, int in1, int in2, int enB, int in3, int in4) {
	this->enA = enA;
	this->in1 = in1;
	this->in2 = in2;
	this->enB = enB;
	this->in3 = in3;
	this->in4 = in4;
	setup_pins();
}

void DB_Motor::setup_pins() {	
	pinMode(enA, OUTPUT);
	pinMode(enB, OUTPUT);
	pinMode(in1, OUTPUT);
	pinMode(in2, OUTPUT);
	pinMode(in4, OUTPUT);
	pinMode(in3, OUTPUT);
}

void DB_Motor::drive_forward(int val) {
	digitalWrite(in1, HIGH);
	digitalWrite(in2, LOW);
	digitalWrite(in3, HIGH);
	digitalWrite(in4, LOW);
	analogWrite(enB, val);
	analogWrite(enA, val);
}

void DB_Motor::drive_backward(int val) {
	digitalWrite(in1, LOW);
	digitalWrite(in2, HIGH);
	digitalWrite(in3, LOW);
	digitalWrite(in4, HIGH);
	analogWrite(enB, val);
	analogWrite(enA, val);
}

	

void DB_Motor::stop() {
	digitalWrite(in1, LOW);
	digitalWrite(in2, LOW);
	digitalWrite(in3, LOW);
	digitalWrite(in4, LOW);
}

void DB_Motor::turn_left(int val) {
	stop();
	digitalWrite(in1, HIGH);
	digitalWrite(in2, LOW);
	digitalWrite(in3, LOW);
	digitalWrite(in4, HIGH);
	analogWrite(enB, val);
	analogWrite(enA, val);
}

void DB_Motor::turn_right(int val) {
	stop();
	digitalWrite(in1, LOW);
	digitalWrite(in2, HIGH);
	digitalWrite(in3, HIGH);
	digitalWrite(in4, LOW);
	analogWrite(enB, val);
	analogWrite(enA, val);
}

	