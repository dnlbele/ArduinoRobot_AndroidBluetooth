#ifndef _DB_MOTOR_H_
#define _DB_MOTOR_H_

#include "Arduino.h"

class DB_Motor {
private:
	// Motor A
	int enA;
	int in1;
	int in2;
	// Motor B
	int enB;
	int in3;
	int in4;
	void setup_pins();


public:
	DB_Motor(int enA, int in1, int in2, int enB, int in3, int in4);
	void drive_forward(int val);
	void drive_backward(int val);
	void stop();
	void turn_right(int val);
	void turn_left(int val);
};

#endif